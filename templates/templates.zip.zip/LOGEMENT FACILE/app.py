from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)
app.config["SECRET_KEY"] = "logement-facile-secret-key-change-en-production"

# Données en mémoire (remplacer par une base de données plus tard)
maisons = [
    {
        "id": 1,
        "commune": "Kipé",
        "prix": "2 000 000",
        "description": "Belle maison avec jardin, proche des commodités.",
        "latitude": 9.6432,
        "longitude": -13.5784,
    },
    {
        "id": 2,
        "commune": "Lambanyi",
        "prix": "1 500 000",
        "description": "Appartement lumineux, quartier calme.",
        "latitude": 9.6200,
        "longitude": -13.6000,
    },
    {
        "id": 3,
        "commune": "Sonfonia",
        "prix": "800 000",
        "description": "Studio équipé, idéal pour une personne.",
        "latitude": 9.6800,
        "longitude": -13.6300,
    },
]


@app.route("/")
def accueil():
    return render_template("index.html", maisons=maisons)


@app.route("/connexion", methods=["GET", "POST"])
def connexion():
    if request.method == "POST":
        # TODO: intégrer une vraie authentification
        return redirect(url_for("accueil"))
    return render_template("connexion.html")


@app.route("/ajouter")
def ajouter():
    return redirect(url_for("publier"))


@app.route("/avis")
def avis():
    return render_template("avis.html")


@app.route("/maisons")
def maisons_page():
    return render_template("maisons.html", maisons=maisons)


@app.route("/contact", methods=["GET", "POST"])
def contact():
    if request.method == "POST":
        # TODO: enregistrer ou envoyer le message
        return redirect(url_for("accueil"))
    return render_template("contact.html")


@app.route("/publier", methods=["GET", "POST"])
def publier():
    if request.method == "POST":
        commune = request.form.get("commune", "").strip()
        prix = request.form.get("prix", "").strip()
        description = request.form.get("description", "").strip()
        try:
            latitude = float(request.form.get("latitude", "9.6412"))
        except ValueError:
            latitude = 9.6412
        try:
            longitude = float(request.form.get("longitude", "-13.5784"))
        except ValueError:
            longitude = -13.5784

        if commune and prix and description:
            new_id = max((m.get("id", 0) for m in maisons), default=0) + 1
            maison = {
                "id": new_id,
                "commune": commune,
                "prix": prix,
                "description": description,
                "latitude": latitude,
                "longitude": longitude,
            }
            maisons.append(maison)
            return redirect(url_for("maisons_page"))

    return render_template("publier.html")


if __name__ == "__main__":
    app.run(debug=True, port=5000)
